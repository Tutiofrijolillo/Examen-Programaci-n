﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace guia1unidad3
{
    public partial class Form1 : Form
    {
        SqlConnection conexion = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=Empleados;Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }
        private void registros()
        {
            try
            {
                conexion.Open();
                SqlDataAdapter comando = new SqlDataAdapter("SELECT * FROM Empleados", conexion);
                DataSet d = new DataSet();
                comando.Fill(d,"nombre");
                dataGridView1.DataSource = d.Tables["nombre"].DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al consultar la base de datos: " + ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("Por favor complete todos los campos.");
                }
                else
                {
                    conexion.Open();
                    SqlCommand comando = new SqlCommand("INSERT INTO Empleados VALUES (@Nombres, @Apellidos,@Ciudad,@direccion, @telefono,@fecha_nacimiento)", conexion);
                    comando.Parameters.AddWithValue("@Nombres", textBox1.Text);
                    comando.Parameters.AddWithValue("@Apellidos", textBox2.Text);
                    comando.Parameters.AddWithValue("@Ciudad", textBox4.Text);
                    comando.Parameters.AddWithValue("@direccion", textBox5.Text);
                    comando.Parameters.AddWithValue("@telefono", Convert.ToInt32(textBox3.Text));
                    comando.Parameters.AddWithValue("@fecha_nacimiento", textBox6.Text);
                    comando.ExecuteNonQuery();
                    MessageBox.Show("Datos agregados exitosamente");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error con la base de datos: " + ex.Message);
            }
            finally
            {
                conexion.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            registros();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
                {
                    MessageBox.Show("Por favor complete todos los campos.");
                }
                else
                {
                    conexion.Open();
                    SqlCommand comando = new SqlCommand("update Empleados set Nombres = @Nombres, Apellidos = @Apellidos, Ciudad = @Ciudad, Direccion = @direccion, telefono = @telefono, fecha_nacimiento = @fecha_nacimiento where id = @ID", conexion);
                    comando.Parameters.AddWithValue("@Nombres", textBox1.Text);
                    comando.Parameters.AddWithValue("@Apellidos", textBox2.Text);
                    comando.Parameters.AddWithValue("@Ciudad", textBox4.Text);
                    comando.Parameters.AddWithValue("@direccion", textBox5.Text);
                    comando.Parameters.AddWithValue("@telefono", Convert.ToInt32(textBox3.Text));
                    comando.Parameters.AddWithValue("@fecha_nacimiento", textBox6.Text);
                    comando.Parameters.AddWithValue("@ID", textBox7.Text);
                    comando.ExecuteNonQuery();
                    MessageBox.Show("Actualizado exitosamente");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error con la base de datos: " + ex.Message);
            }
            finally
            {
                conexion.Close();
                registros();
            }
        }
        

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox7.Text == "")
                {
                    MessageBox.Show("Por favor, ingrese el ID.");
                }
                else
                {
                    conexion.Open();
                    SqlCommand comando = new SqlCommand("delete from Empleados where id = @ID", conexion);
                    comando.Parameters.AddWithValue("@ID", textBox7.Text);
                    comando.ExecuteNonQuery();
                    MessageBox.Show("Eliminado exitosamente");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error con la base de datos: " + ex.Message);
            }
            finally
            {
                conexion.Close();
                registros();
            }
        }
    }
}